//This file store.jsx is not required,if we don't create then it shows perfect output as well.
import { createStore } from "redux";
import counterReducer from "./reducer/CounterReducer";

function configureStore(state = 0) {
  return createStore( counterReducer,state);
}
export default configureStore;
